package com.example.hotel;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

public class MainActivity extends AppCompatActivity {

    private BottomSheetDialog bottomSheetDialog;
    private TextView roomCountTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        @SuppressLint("MissingInflatedId") Button openBottomSheetButton = findViewById(R.id.openBottomSheetButton);
        openBottomSheetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showBottomSheet();
            }
        });

        roomCountTextView = findViewById(R.id.roomCountTextView);
    }

    private void showBottomSheet() {
        View bottomSheetView = getLayoutInflater().inflate(R.layout.bottomsheet, null);

        Button roomDecrementButton = bottomSheetView.findViewById(R.id.roomDecrementButton);
        Button roomIncrementButton = bottomSheetView.findViewById(R.id.roomIncrementButton);
        Button adultDecrementButton = bottomSheetView.findViewById(R.id.adultDecrementButton);
        Button adultIncrementButton = bottomSheetView.findViewById(R.id.adultIncrementButton);
        Button childrenDecrementButton = bottomSheetView.findViewById(R.id.childrenDecrementButton);
        Button childrenIncrementButton = bottomSheetView.findViewById(R.id.childrenIncrementButton);
        Button save = bottomSheetView.findViewById(R.id.saveButton);
        final TextView roomCountTextView = bottomSheetView.findViewById(R.id.roomCountTextView);
        final TextView adultCountTextView = bottomSheetView.findViewById(R.id.adultCountTextView);
        final TextView childrenCountTextView = bottomSheetView.findViewById(R.id.childrenCountTextView);


        roomDecrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                decrementRoomCount(roomCountTextView);
            }
        });
       adultDecrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                decrementadultCount(adultCountTextView);
            }
        });


        roomIncrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                incrementRoomCount(roomCountTextView);
            }
        });
        adultIncrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                incrementadultCount(adultCountTextView);
            }
        });


        childrenIncrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                incrementRoomCount(childrenCountTextView);
            }
        });
        childrenIncrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                incrementadultCount(childrenCountTextView);
            }
        });








        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String roomCount = roomCountTextView.getText().toString();
                String adultCount = adultCountTextView.getText().toString();
                String childrenCount = childrenCountTextView.getText().toString();
                TextView selectedRoomTextView = findViewById(R.id.selectedRoomTextView);
                TextView selectedadultTextView = findViewById(R.id.selectedadultTextView);
                TextView selectedchildrenTextView = findViewById(R.id.selectedchildrenTextView);
                selectedRoomTextView.setText(roomCount);
                selectedadultTextView.setText(adultCount);
                selectedchildrenTextView.setText(childrenCount);

                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetDialog = new BottomSheetDialog(MainActivity.this);
        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();
    }

    private void incrementRoomCount(TextView textView) {
        int roomCount = Integer.parseInt(textView.getText().toString()) + 1;
        textView.setText(String.valueOf(roomCount));
    }

    private void incrementchildrenCount(TextView textView) {
        int roomCount = Integer.parseInt(textView.getText().toString()) + 1;
        textView.setText(String.valueOf(roomCount));
    }

    private void incrementadultCount(TextView textView) {
        int roomCount = Integer.parseInt(textView.getText().toString()) + 1;
        textView.setText(String.valueOf(roomCount));
    }

    private void decrementRoomCount(TextView textView) {
        int roomCount = Integer.parseInt(textView.getText().toString());
        if (roomCount > 1) {
            roomCount--;
            textView.setText(String.valueOf(roomCount));
        }
    }

    private void decrementadultCount(TextView textView) {
        int roomCount = Integer.parseInt(textView.getText().toString());
        if (roomCount > 1) {
            roomCount--;
            textView.setText(String.valueOf(roomCount));
        }
    }

    private void decrementchildrenCount(TextView textView) {
        int roomCount = Integer.parseInt(textView.getText().toString());
        if (roomCount > 1) {
            roomCount--;
            textView.setText(String.valueOf(roomCount));
        }
    }


}